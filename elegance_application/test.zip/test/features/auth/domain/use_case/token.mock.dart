import 'package:elegance_application/app/shared_prefs/token_shared_prefs.dart';
import 'package:mocktail/mocktail.dart';

class MockTokenSharedPrefs extends Mock implements TokenSharedPrefs {}