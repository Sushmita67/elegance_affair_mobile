import 'package:elegance_application/features/auth/domain/repository/user_repository.dart';
import 'package:mocktail/mocktail.dart';

class MockAuthRepository extends Mock implements IUserRepository {}
