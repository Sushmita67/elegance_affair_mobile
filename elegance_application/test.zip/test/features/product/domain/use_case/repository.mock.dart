import 'package:elegance_application/features/product/domain/repository/product_repository.dart';
import 'package:mocktail/mocktail.dart';

class MockProductRepository extends Mock implements IProductRepository {}
